BCC_PATH=$(cd $(dirname ${BASH_SOURCE:-$0});pwd)
echo $BCC_PATH
export PATH=$BCC_PATH/FlameGraph-master:$PATH
mkdir $1/output_svg
ls $1| \
while read item ;
    do  if [[ "$item" == *.folded  ]] ;
    then flamegraph.pl \
	      < $1/$item \
       	>  $1/output_svg/${item%*.folded}.svg
      rm $1/$item
    fi;
done

