#!bin/bash 
export PATH=/mnt/vblkdev1/sunweijie02/bccprofile/FlameGraph-master:$PATH

for 
flamegraph 