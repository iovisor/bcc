import os
import argparse

if __name__ == '__main__':
  parser = argparse.ArgumentParser(
    description="Get address from libso",
    formatter_class=argparse.RawDescriptionHelpFormatter
    )
  parser.add_argument("--dir", type = str,required = True,
    help="profile process with this PID only")
  args = parser.parse_args()
  g =  os.walk("{}".format(args.dir))
  for root, dirs, files in g:
    for file in files:
      if(file.split('.')[1] != 'log'):
        continue
      curpath ="{}/{}".format(root,file)
      f = open(curpath)
      contents = f.read().split('bcc_profile ')
      for content in contents:
        if(len(content) == 0) :
          continue
        time,content = content.split('\n',1)  
        if len(time) < 2:
            continue
        time = time.split(': ')[1]
        f = open('{}/{}.folded'.format(root,time),"w")
        f.write(content)
        f.close()
      # print(contents)
      
        
